package com.intentapp.fblogin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.view.SupportActionModeWrapper;
import android.widget.TextView;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;

public class MainActivity extends AppCompatActivity {

    TextView txtStatus;
    LoginButton login_button;
    CallbackManager callbackManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FacebookSdk.sdkInitialize(getApplicationContext());
        setContentView(R.layout.activity_main);
        initializeControls();

       loginwithfb();
    }

    void initializeControls() {
        callbackManager=CallbackManager.Factory.create();
        txtStatus=(TextView)findViewById(R.id.txtStatus);
        login_button=(LoginButton)findViewById(R.id.login_button);

    }
    void loginwithfb() {
        LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>(){
            public void onSuccess(LoginResult loginResult) {
                txtStatus.setText("Login Success"+loginResult.getAccessToken());
            }

            public void onCancel () {
                txtStatus.setText("Login Cancelled");

            }

            public void onError(FacebookException e) {
                txtStatus.setText("Login attempt failed.");

            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
    }
}
